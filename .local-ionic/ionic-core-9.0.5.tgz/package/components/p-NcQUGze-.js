/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const t=t=>{const o=t.classList.contains("ion-touched"),n=t.classList.contains("ion-invalid");return o&&n},o=(t,o)=>{var n;if(t?.validity)if(t.validity.valid)o.setValidity({});else{const r={badInput:(n=t.validity).badInput,customError:n.customError,patternMismatch:n.patternMismatch,rangeOverflow:n.rangeOverflow,rangeUnderflow:n.rangeUnderflow,stepMismatch:n.stepMismatch,tooLong:n.tooLong,tooShort:n.tooShort,typeMismatch:n.typeMismatch,valueMissing:n.valueMissing};o.setValidity(r,t.validationMessage,t)}};export{t as c,o as r}