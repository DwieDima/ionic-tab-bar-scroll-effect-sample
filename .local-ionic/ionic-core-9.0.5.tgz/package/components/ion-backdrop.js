/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{B as o,d as s}from"./p-CS2cNbCS.js";const p=o,r=s;export{p as IonBackdrop,r as defineCustomElement}