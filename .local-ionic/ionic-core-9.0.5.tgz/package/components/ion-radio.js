/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{R as o,d as r}from"./p-CT5LqgrM.js";const s=o,p=r;export{s as IonRadio,p as defineCustomElement}