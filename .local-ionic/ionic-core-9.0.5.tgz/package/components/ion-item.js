/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{I as o,d as s}from"./p-D7znVlKc.js";const p=o,r=s;export{p as IonItem,r as defineCustomElement}