/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{I as o,d as s}from"./p-C3Wg3X46.js";const p=o,r=s;export{p as IonIcon,r as defineCustomElement}