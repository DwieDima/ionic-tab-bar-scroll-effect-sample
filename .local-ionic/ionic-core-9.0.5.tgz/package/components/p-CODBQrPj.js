/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const a=(a,o,i)=>"ionic"===a||"ios"===a&&"radio"===o&&"modal"!==i?"start":"end",o=(a,o,i)=>"ionic"===a||"ios"===a&&"radio"===o&&"modal"!==i?"space-between":"start";export{a,o as g}