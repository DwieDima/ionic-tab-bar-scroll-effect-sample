/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{C as o,d as s}from"./p-oTWYxtQO.js";const t=o,p=s;export{t as IonCheckbox,p as defineCustomElement}