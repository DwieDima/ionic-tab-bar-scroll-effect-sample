/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{C as o,d as s}from"./p-DZ1ek32R.js";const p=o,r=s;export{p as IonContent,r as defineCustomElement}