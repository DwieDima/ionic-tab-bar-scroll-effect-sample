/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{A as o,d as s}from"./p-5TOEeH0b.js";const p=o,r=s;export{p as IonActionSheet,r as defineCustomElement}