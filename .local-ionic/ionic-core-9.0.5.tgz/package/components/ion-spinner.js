/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{a as o,d as s}from"./p-DqQcTKzN.js";const a=o,p=s;export{a as IonSpinner,p as defineCustomElement}