/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{R as o,d as p}from"./p-DjdphE5m.js";const s=o,m=p;export{s as IonRippleEffect,m as defineCustomElement}