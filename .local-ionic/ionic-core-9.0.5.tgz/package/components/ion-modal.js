/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{M as m,d as o}from"./p-1Qv4vmCm.js";const s=m,p=o;export{s as IonModal,p as defineCustomElement}