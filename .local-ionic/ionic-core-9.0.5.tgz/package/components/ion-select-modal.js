/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{S as o,d as s}from"./p-AY_dAkCe.js";const p=o,r=s;export{p as IonSelectModal,r as defineCustomElement}