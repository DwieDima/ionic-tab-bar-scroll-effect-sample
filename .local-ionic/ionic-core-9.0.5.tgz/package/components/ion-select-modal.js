/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{S as o,d as r}from"./p-D-rZWDEl.js";const s=o,p=r;export{s as IonSelectModal,p as defineCustomElement}