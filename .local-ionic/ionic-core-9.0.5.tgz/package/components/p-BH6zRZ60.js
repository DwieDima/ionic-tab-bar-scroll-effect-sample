/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{m as a}from"./p-QyRd8Ndx.js";const t=async t=>{const s=await a.get(t);return!(!s||!await s.isActive())};export{t as u}