import type { Components, JSX } from "../dist/types/components";

interface IonGallery extends Components.IonGallery, HTMLElement {}
export const IonGallery: {
    prototype: IonGallery;
    new (): IonGallery;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
