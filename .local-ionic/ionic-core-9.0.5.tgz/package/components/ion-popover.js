/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{P as o,d as s}from"./p-v50Adxc1.js";const p=o,r=s;export{p as IonPopover,r as defineCustomElement}