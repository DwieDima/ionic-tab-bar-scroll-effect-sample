/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{A as o,d as s}from"./p-1vibmejT.js";const m=o,p=s;export{m as IonAlert,p as defineCustomElement}