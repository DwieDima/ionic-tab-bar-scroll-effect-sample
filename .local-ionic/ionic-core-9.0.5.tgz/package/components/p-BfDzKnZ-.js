/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{d as o}from"./p-ZjP4CjeZ.js";const e=e=>{const c=()=>{o?.removeEventListener("click",c),e(!1)};return{onPointerDown:r=>{r.preventDefault(),0===r.button&&(e(!0),o?.addEventListener("click",c,{once:!0}))},release:c,destroy:()=>{c()}}};export{e as c}