import type { Components, JSX } from "../dist/types/components";

interface IonGalleryItem extends Components.IonGalleryItem, HTMLElement {}
export const IonGalleryItem: {
    prototype: IonGalleryItem;
    new (): IonGalleryItem;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
