/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{H as s,d as o}from"./p-CJ8srI03.js";const r=s,p=o;export{r as IonHeader,p as defineCustomElement}