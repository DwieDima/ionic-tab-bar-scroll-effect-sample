/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import"./p-jQ2tnsHV.js";const t=(t,e,n=["item-multiple-inputs"])=>{const s=t.closest("ion-item");if(!s||"undefined"==typeof MutationObserver)return;const i=()=>n.map((t=>s.classList.contains(t))).join(",");let r=i();const o=new MutationObserver((()=>{const t=i();t!==r&&(r=t,e())}));return o.observe(s,{attributes:!0,attributeFilter:["class"]}),o};export{t as c}