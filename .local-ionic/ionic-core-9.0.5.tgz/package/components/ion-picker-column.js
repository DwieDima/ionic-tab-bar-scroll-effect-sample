/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{P as o,d as s}from"./p-CXGkMOcR.js";const p=o,r=s;export{p as IonPickerColumn,r as defineCustomElement}