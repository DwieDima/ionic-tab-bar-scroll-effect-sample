/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{L as s,d as o}from"./p-CsnhiGn6.js";const n=s,p=o;export{n as IonListHeader,p as defineCustomElement}