/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{P as o,d as r}from"./p-NBoRwrom.js";const s=o,m=r;export{s as IonPicker,m as defineCustomElement}