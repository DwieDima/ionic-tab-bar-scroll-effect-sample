import type { Components, JSX } from "../dist/types/components";

interface IonDivider extends Components.IonDivider, HTMLElement {}
export const IonDivider: {
    prototype: IonDivider;
    new (): IonDivider;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
