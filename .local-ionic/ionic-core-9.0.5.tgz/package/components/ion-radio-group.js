/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{R as o,d as p}from"./p-M60p_T0t.js";const s=o,t=p;export{s as IonRadioGroup,t as defineCustomElement}