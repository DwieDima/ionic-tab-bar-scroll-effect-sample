/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{L as o,d as s}from"./p-t-P1bHMe.js";const t=o,p=s;export{t as IonLabel,p as defineCustomElement}