/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{B as o,d as s}from"./p-Bm3TJg8U.js";const m=o,p=s;export{m as IonButtons,p as defineCustomElement}