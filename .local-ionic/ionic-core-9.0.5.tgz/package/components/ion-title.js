/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{T as o,d as s}from"./p-Cxq-C8Vh.js";const p=o,r=s;export{p as IonTitle,r as defineCustomElement}