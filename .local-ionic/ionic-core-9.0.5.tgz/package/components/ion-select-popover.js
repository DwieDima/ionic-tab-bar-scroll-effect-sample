/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{S as o,d as p}from"./p-Rm7upSzB.js";const s=o,m=p;export{s as IonSelectPopover,m as defineCustomElement}