/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{u as o,w as s}from"./p-jQ2tnsHV.js";import{a as t,s as n}from"./p-B3n2hdAS.js";import{c as r}from"./p-R8byHRhe.js";const a=()=>{const a=window;a.addEventListener("statusTap",(()=>{o((()=>{const o=document.elementFromPoint(a.innerWidth/2,a.innerHeight/2);if(!o)return;const e=t(o);e&&new Promise((o=>r(e,o))).then((()=>{s((async()=>{e.style.setProperty("--overflow","hidden"),await n(e,300),e.style.removeProperty("--overflow")}))}))}))}))};export{a as startStatusTap}