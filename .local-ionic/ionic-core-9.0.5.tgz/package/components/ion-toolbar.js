/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{T as o,d as s}from"./p-DDxQoIC9.js";const p=o,r=s;export{p as IonToolbar,r as defineCustomElement}