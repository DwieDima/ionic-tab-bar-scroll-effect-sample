/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import{L as o,d as s}from"./p-4ANLTUuh.js";const p=o,r=s;export{p as IonList,r as defineCustomElement}